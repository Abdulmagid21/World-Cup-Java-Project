
import javafx.application.Application;
import java.io.File;
import java.util.ArrayList;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.geometry.Insets;
import javafx.scene.paint.Color;




public class GUI {
    static final int WIDTH_OF_HBOX = 2000;
   

    public static BorderPane setupGUI(BorderPane root) {
        root.setLeft(setupLeft());
        root.getLeft().setId("vbox-left");
        Main.computeRanking();
        Main.setupGames();
       root.setCenter(setupCenter());
       root.getCenter().setId("root");
      

        return root;
    }

   
    private static HBox setupCenter() {
       
        HBox center = new HBox();
        if (Main.teams.size() > 1) {
            center = setupCenterRegular();
                }
        return center;
    }

    
    private static HBox setupCenterRegular() {
        HBox center = new HBox();
        ArrayList<VBox> vBoxList = new ArrayList<VBox>();
        int index = 0; 

        
        int vBoxNum = 7; 

        
        for (int i = 0; i < vBoxNum; i++) {
            VBox temp = new VBox();
            temp.setPrefWidth(WIDTH_OF_HBOX / (double) vBoxNum * 20);
            temp.setId("vbox-big");
            vBoxList.add(temp);
        }

        
        VBox blank = new VBox();
        blank.getStyleClass().add("vbox-blank");

       
        VBox temp = Main.games.get(Main.games.size() - 1).setUpVBox();
        temp.setPrefWidth(WIDTH_OF_HBOX / (double) vBoxNum - 15);
        vBoxList.get(vBoxNum / 2).getChildren().addAll(temp, blank);

        
        for (int i = 0; i < vBoxNum / 2; i++) {
           

            for (int j = 0; j < (int) Math.pow(2, vBoxNum / 2 - 1 - i); j++) {
                VBox blank1 = new VBox();
                blank1.getStyleClass().add("vbox-blank");
                VBox temp1 = Main.games.get(index).setUpVBox();
                temp1.setPrefWidth(WIDTH_OF_HBOX / (double) vBoxNum - 15);
                vBoxList.get(i).getChildren().addAll(temp1, blank1);
                index++;
            }
            for (int j = 0; j < (int) Math.pow(2, vBoxNum / 2 - 1 - i); j++) {
                VBox blank2 = new VBox();
                blank2.getStyleClass().add("vbox-blank");
                VBox temp2 = Main.games.get(index).setUpVBox();
                temp2.setPrefWidth(WIDTH_OF_HBOX / (double) vBoxNum - 15);
                vBoxList.get(vBoxList.size() - i - 1).getChildren().addAll(temp2, blank2);
                index++;
            }

        }

        for (int i = 0; i < vBoxList.size(); i++)
            center.getChildren().add(vBoxList.get(i));

        return center;
    }

    private static VBox setupLeft() {
        VBox left = new VBox();
        Main.teamList = setupTeamList();
        left.getChildren().addAll( Main.teamList);
        return left;
    }

   
    private static VBox setupTeamList() {
        VBox teamList = new VBox();
        Label labelHead = new Label();
        labelHead.setText("Tournament");
        labelHead.setFont(new Font("Impact", 15));
        labelHead.setId("label-head");
        teamList.getChildren().add(labelHead);

        for (Team team : Main.teams) {
            Label label = new Label();
            label.setText(team.getRank() + "  " + team.getName());
            label.setFont(new Font("Impact", 13));
            label.getStyleClass().add("label-names");
            teamList.getChildren().add(label);
        }
        teamList.setId("vbox-names");
        return teamList;
    }



}