import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.util.Scanner;
import java.io.*;


public class GroupStage{

    
    String groups[] = {"Qatar", "Ecuador", "Senegal", "Netherlands",
                       "England", "Iran", "USA", "Wales",
                       "Argentina", "Saudi Arabia", "Mexico", "Poland",
                       "France", "Australia", "Denmark", "Tunisia",
                       "Spain", "Costa Rica", "Germany", "Japan",
                       "Belgium", "Canada", "Morocco", "Croatia",
                       "Brazil", "Serbia", "Switzerland", "Cameroon",
                       "Portugal", "Ghana", "Uruguay", "South Korea"};
    
   
    
    void game() {
    
    try (PrintWriter out = new PrintWriter("GroupWinners.txt")) {
       
               for (int i = 0; i < 8; i++) {
            int winner1 = (int)(Math.random() * 4);
            int winner2 = (int)(Math.random() * 4);
          
            while (winner1 == winner2) {
                winner2 = (int)(Math.random() * 4);
            }
            int groupStart = i * 4;
            String groupWinner1 = groups[groupStart + winner1];
            String groupWinner2 = groups[groupStart + winner2];
            out.println(groupWinner1 + "\n" + groupWinner2);
        }
    } catch (FileNotFoundException e) {
        e.printStackTrace();
    }
}
    
    
    public static void main(String[] args) {
        
        GroupStage groupstage = new GroupStage();
        
       
        groupstage.game();
    }
}


